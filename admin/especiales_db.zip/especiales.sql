# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# servidor: localhost
# Tiempo de Generacion: 17-02-2004 a les 17:48:06
# Version del Servidor: 4.00.00
# Version del PHP: 4.2.2
# Base De Datos : `especiales`
# --------------------------------------------------------

#
# Estructura de tabla para tabla `agencias`
#

CREATE TABLE agencias (
  id int(11) NOT NULL auto_increment,
  agencia varchar(255) NOT NULL default '',
  id_pais int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `agencias`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `autores`
#

CREATE TABLE autores (
  id int(11) NOT NULL auto_increment,
  autor varchar(255) NOT NULL default '',
  mail varchar(100) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `autores`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `columnistas`
#

CREATE TABLE columnistas (
  id int(11) NOT NULL auto_increment,
  nombre varchar(255) NOT NULL default '',
  archivo_columnista varchar(50) default NULL,
  email varchar(100) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `columnistas`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `destinos`
#

CREATE TABLE destinos (
  id int(10) NOT NULL auto_increment,
  destino char(100) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `destinos`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `encuestas_preguntas`
#

CREATE TABLE encuestas_preguntas (
  id int(11) NOT NULL auto_increment,
  pregunta varchar(255) NOT NULL default '',
  fecha_inicio date NOT NULL default '0000-00-00',
  fecha_fin date NOT NULL default '0000-00-00',
  id_trivia int(10) default NULL,
  orden int(5) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `encuestas_preguntas`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `encuestas_respuestas`
#

CREATE TABLE encuestas_respuestas (
  id int(11) NOT NULL auto_increment,
  respuesta varchar(255) NOT NULL default '',
  id_preguntas int(10) NOT NULL default '0',
  votos int(5) default '0',
  orden int(5) NOT NULL default '0',
  ck_correcta tinyint(1) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `encuestas_respuestas`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `entrevistas`
#

CREATE TABLE entrevistas (
  id int(11) NOT NULL auto_increment,
  titulo varchar(255) NOT NULL default '',
  copete text NOT NULL,
  cuerpo longtext NOT NULL,
  id_pais int(10) default NULL,
  id_deporte int(10) default NULL,
  id_liga int(10) default NULL,
  entrevistado varchar(100) default NULL,
  id_foto int(10) default '0',
  id_autor int(10) default NULL,
  audio varchar(255) default NULL,
  fecha_creacion datetime default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `entrevistas`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `estructura`
#

CREATE TABLE estructura (
  id int(10) unsigned NOT NULL auto_increment,
  nombre varchar(50) NOT NULL default '',
  id_estructura int(10) unsigned default '0',
  link longtext,
  tipo int(5) NOT NULL default '0',
  ck_activa tinyint(1) default NULL,
  orden int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY id_padre (id_estructura)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `estructura`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `estructura_contenido`
#

CREATE TABLE estructura_contenido (
  id int(11) NOT NULL auto_increment,
  id_estructura int(10) NOT NULL default '0',
  id_lista_tablas int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `estructura_contenido`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `fotos`
#

CREATE TABLE fotos (
  id int(11) NOT NULL auto_increment,
  alias varchar(255) NOT NULL default '',
  archivo_imagen varchar(255) default NULL,
  id_pais int(10) default NULL,
  id_deporte int(10) default NULL,
  id_liga int(10) default NULL,
  id_agencias int(10) default NULL,
  palablas_claves varchar(255) default NULL,
  fecha_creacion datetime default NULL,
  PRIMARY KEY  (id),
  KEY alias (alias)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `fotos`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `fotos_agencias`
#

CREATE TABLE fotos_agencias (
  id int(11) NOT NULL auto_increment,
  agencia varchar(255) NOT NULL default '',
  id_pais int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `fotos_agencias`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_acciones`
#

CREATE TABLE futbol_acciones (
  id int(11) NOT NULL auto_increment,
  id_partido int(10) NOT NULL default '0',
  accion int(5) NOT NULL default '0',
  minuto int(3) NOT NULL default '0',
  tiempo int(3) default '0',
  descripcion varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_acciones`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_cambios`
#

CREATE TABLE futbol_cambios (
  id int(11) NOT NULL auto_increment,
  id_partido int(10) NOT NULL default '0',
  id_sale_jugador int(10) NOT NULL default '0',
  id_entra_jugador int(10) NOT NULL default '0',
  minuto int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_cambios`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_clubes`
#

CREATE TABLE futbol_clubes (
  id int(11) NOT NULL auto_increment,
  nombre varchar(250) NOT NULL default '',
  alias varchar(100) NOT NULL default '',
  fundacion longtext,
  titulos longtext,
  direccion longtext,
  id_pais int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_clubes`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_descenso`
#

CREATE TABLE futbol_descenso (
  id int(11) NOT NULL auto_increment,
  id_club int(10) NOT NULL default '0',
  ac_1_2_pts int(10) default '0',
  ac_1_2_pj int(10) default '0',
  ac_2_3_pts int(10) default '0',
  ac_2_3_pj int(10) default '0',
  ac_3_4_pts int(10) default '0',
  ac_3_4_pj int(10) default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_descenso`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_formacion`
#

CREATE TABLE futbol_formacion (
  id int(11) NOT NULL auto_increment,
  id_partido int(10) NOT NULL default '0',
  id_jugador int(10) NOT NULL default '0',
  orden int(3) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_formacion`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_goleadores`
#

CREATE TABLE futbol_goleadores (
  id int(11) NOT NULL auto_increment,
  id_partido int(11) NOT NULL default '0',
  id_jugador int(11) NOT NULL default '0',
  id_tipo_goles int(11) NOT NULL default '0',
  minuto int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_goleadores`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_jugadores`
#

CREATE TABLE futbol_jugadores (
  id int(11) NOT NULL auto_increment,
  apellido varchar(100) NOT NULL default '',
  nombre varchar(100) default NULL,
  apodo varchar(100) default NULL,
  fecha_nacimiento date default '0000-00-00',
  lugar_nacimiento varchar(200) default NULL,
  id_puesto int(10) default '0',
  numero int(2) default '0',
  altura varchar(30) default NULL,
  peso varchar(30) default NULL,
  debut_en_primera varchar(200) default NULL,
  trayectoria longtext,
  titulos longtext,
  id_jugadores_fotos int(11) default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_jugadores`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_jugadores_puestos`
#

CREATE TABLE futbol_jugadores_puestos (
  id int(11) NOT NULL auto_increment,
  puesto char(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_jugadores_puestos`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_partidos`
#

CREATE TABLE futbol_partidos (
  id int(11) NOT NULL auto_increment,
  id_torneo int(11) NOT NULL default '0',
  orden_llave int(10) default '0',
  numero_fecha int(10) default '0',
  grupo int(5) default '0',
  id_primer_club int(10) NOT NULL default '0',
  goles_primer_club int(5) default '0',
  penales_primer_club int(5) default '0',
  id_segundo_club int(10) NOT NULL default '0',
  goles_segundo_club int(5) default '0',
  penales_segundo_club int(5) default '0',
  fecha_partido date NOT NULL default '0000-00-00',
  hora_partido time default NULL,
  estadio varchar(200) default NULL,
  arbitro varchar(200) default NULL,
  lineas varchar(200) default NULL,
  id_partidos_estados int(10) default NULL,
  comentario varchar(200) default NULL,
  cronica longtext,
  ck_mam tinyint(1) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_partidos`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_partidos_estados`
#

CREATE TABLE futbol_partidos_estados (
  id int(11) NOT NULL auto_increment,
  estado_partido varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_partidos_estados`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_planteles`
#

CREATE TABLE futbol_planteles (
  id int(11) NOT NULL auto_increment,
  id_clubes int(11) NOT NULL default '0',
  id_jugador int(11) NOT NULL default '0',
  id_torneo int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_planteles`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_resumen`
#

CREATE TABLE futbol_resumen (
  id int(11) NOT NULL auto_increment,
  id_torneo int(10) NOT NULL default '0',
  id_primer_club int(10) NOT NULL default '0',
  goles_primer_club int(10) NOT NULL default '0',
  id_segundo_club int(10) NOT NULL default '0',
  goles_segundo_club int(10) NOT NULL default '0',
  fecha_partido date default NULL,
  hora_partido time default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_resumen`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_tarjetas`
#

CREATE TABLE futbol_tarjetas (
  id int(11) NOT NULL auto_increment,
  id_partido int(10) NOT NULL default '0',
  id_jugador int(10) NOT NULL default '0',
  minuto int(10) NOT NULL default '0',
  tarjeta smallint(1) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_tarjetas`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_tipo_goles`
#

CREATE TABLE futbol_tipo_goles (
  id int(11) NOT NULL auto_increment,
  tipo varchar(100) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_tipo_goles`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `futbol_torneos`
#

CREATE TABLE futbol_torneos (
  id int(11) NOT NULL auto_increment,
  torneo varchar(200) NOT NULL default '',
  cantidad_grupos int(5) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `futbol_torneos`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `noticias`
#

CREATE TABLE noticias (
  id int(11) NOT NULL auto_increment,
  titulo varchar(42) NOT NULL default '',
  copete varchar(182) NOT NULL default '',
  cuerpo longtext,
  id_foto int(10) default NULL,
  epigrafe varchar(255) default NULL,
  id_pais int(4) NOT NULL default '0',
  id_deporte int(10) NOT NULL default '0',
  id_liga int(10) default NULL,
  id_autor tinyint(4) default NULL,
  audio varchar(255) default NULL,
  fecha_creacion datetime default NULL,
  _timestamp int(14) default NULL,
  _id_usuario int(10) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `noticias`
#

INSERT INTO noticias VALUES (1, 'test', 'asd', 'kl', 0, '', 0, 0, 0, 0, '', '2004-02-17 17:47:05', 2147483647, 1);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `opiniones`
#

CREATE TABLE opiniones (
  id tinyint(4) NOT NULL auto_increment,
  titulo varchar(255) NOT NULL default '',
  copete text,
  id_columnista int(11) NOT NULL default '0',
  cuerpo longtext NOT NULL,
  id_autor int(10) default NULL,
  fecha_creacion datetime default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `opiniones`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `paises`
#

CREATE TABLE paises (
  id int(11) NOT NULL auto_increment,
  pais varchar(255) NOT NULL default '',
  alias char(3) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `paises`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `publicaciones`
#

CREATE TABLE publicaciones (
  id int(11) NOT NULL auto_increment,
  id_lista_tablas int(10) NOT NULL default '0',
  id_publicado int(10) NOT NULL default '0',
  id_estructura int(10) NOT NULL default '0',
  id_seccion int(10) NOT NULL default '0',
  posicion int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `publicaciones`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `rel_entrevistas`
#

CREATE TABLE rel_entrevistas (
  id int(11) NOT NULL auto_increment,
  id_noticia int(10) NOT NULL default '0',
  id_entrevistas int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `rel_entrevistas`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `rel_noticias`
#

CREATE TABLE rel_noticias (
  id int(11) NOT NULL auto_increment,
  id_noticia int(10) NOT NULL default '0',
  id_noticias int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `rel_noticias`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `rel_opiniones`
#

CREATE TABLE rel_opiniones (
  id int(11) NOT NULL auto_increment,
  id_noticia int(10) NOT NULL default '0',
  id_opiniones int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `rel_opiniones`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `secciones`
#

CREATE TABLE secciones (
  id int(11) NOT NULL auto_increment,
  id_lista_tablas int(10) NOT NULL default '0',
  seccion varchar(255) NOT NULL default '',
  cantidad int(10) NOT NULL default '0',
  orden int(10) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `secciones`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `suscriptos`
#

CREATE TABLE suscriptos (
  id int(11) NOT NULL auto_increment,
  nombre varchar(60) NOT NULL default '',
  apellido varchar(60) NOT NULL default '',
  mail varchar(80) NOT NULL default '',
  clave varchar(6) NOT NULL default '',
  direccion varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `suscriptos`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `trivias`
#

CREATE TABLE trivias (
  id int(11) NOT NULL auto_increment,
  trivia varchar(255) NOT NULL default '',
  ck_activa tinyint(1) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `trivias`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `trivias_participantes`
#

CREATE TABLE trivias_participantes (
  id int(11) NOT NULL auto_increment,
  id_suscripto int(10) NOT NULL default '0',
  id_trivia int(10) NOT NULL default '0',
  ck_correcta tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `trivias_participantes`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `usuarios`
#

CREATE TABLE usuarios (
  id int(11) NOT NULL auto_increment,
  apellido varchar(255) NOT NULL default '',
  nombre varchar(255) NOT NULL default '',
  usuario varchar(255) NOT NULL default '',
  clave varchar(255) NOT NULL default '',
  id_perfil int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `usuarios`
#

INSERT INTO usuarios VALUES (1, 'Raffo Quintana', 'Esteban', 'nak', '38d34d25434cecff', 1);
INSERT INTO usuarios VALUES (2, 'Ramirez', 'Hern�n', 'hramirez', '3c22d7870a1bb02d', 1);
INSERT INTO usuarios VALUES (3, 'Principe', 'Hern�n', 'hprincipe', '1c61baef13d81751', 1);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `usuarios_lista_tablas`
#

CREATE TABLE usuarios_lista_tablas (
  id int(11) NOT NULL auto_increment,
  nombre varchar(255) NOT NULL default '',
  tabla varchar(255) default NULL,
  link varchar(255) default NULL,
  include varchar(255) default NULL,
  descripcion varchar(255) default NULL,
  id_sectores int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `usuarios_lista_tablas`
#

INSERT INTO usuarios_lista_tablas VALUES (42, 'Solapas', 'usuarios_rel_tab', '', NULL, '', 1);
INSERT INTO usuarios_lista_tablas VALUES (41, 'Opiniones', 'opiniones', '', '', '', 11);
INSERT INTO usuarios_lista_tablas VALUES (40, 'Noticias', 'noticias', '', NULL, '', 4);
INSERT INTO usuarios_lista_tablas VALUES (39, 'Fotos', 'fotos', '', NULL, '', 9);
INSERT INTO usuarios_lista_tablas VALUES (23, 'Suscriptos', 'suscriptos', '', NULL, '', 8);
INSERT INTO usuarios_lista_tablas VALUES (37, 'Equipos', 'equipos', '', NULL, '', 4);
INSERT INTO usuarios_lista_tablas VALUES (36, 'Entrevistas', 'entrevistas', '', '', '', 4);
INSERT INTO usuarios_lista_tablas VALUES (35, 'Deportistas', 'deportistas', '', NULL, '', 4);
INSERT INTO usuarios_lista_tablas VALUES (34, 'Deportes', 'deportes', '', '', '', 4);
INSERT INTO usuarios_lista_tablas VALUES (33, 'Audios', 'audios', '', NULL, '', 9);
INSERT INTO usuarios_lista_tablas VALUES (3, 'Permisos', 'usuarios_permisos', NULL, NULL, NULL, 1);
INSERT INTO usuarios_lista_tablas VALUES (1, 'Usuarios', 'usuarios', NULL, NULL, 'Usuarios del administrador', 1);
INSERT INTO usuarios_lista_tablas VALUES (2, 'Tablas', 'usuarios_lista_tablas', NULL, NULL, 'Todas las tablas del admin', 1);
INSERT INTO usuarios_lista_tablas VALUES (43, 'Relacionadas', '', '', 'especiales/relaciones.inc', 'Relacion entra noticias, encuestas y opiniones', 0);
INSERT INTO usuarios_lista_tablas VALUES (44, 'Publicacion', '', '', 'especiales/publicacion.inc', 'Publicacion', 0);
INSERT INTO usuarios_lista_tablas VALUES (47, 'Encuestas', 'encuestas_preguntas', '', '', '', 4);
INSERT INTO usuarios_lista_tablas VALUES (46, 'Videos', 'videos', '', '', '', 9);
INSERT INTO usuarios_lista_tablas VALUES (48, 'Respuestas', '', '', 'especiales/encuestas_respuestas.inc', '', 0);
INSERT INTO usuarios_lista_tablas VALUES (49, 'Estructura', 'estructuras', '', 'especiales/estructura', '', 1);
INSERT INTO usuarios_lista_tablas VALUES (50, 'Preview', 'noticias', 'javascript:abrirVentana(\'../welcome/noticias/popup.php?id_not=<? echo $id ?>\',\'<? echo $id ?>\',485,350);', 'especiales/preview.inc', '', 0);
INSERT INTO usuarios_lista_tablas VALUES (51, 'Agencias', 'fotos_agencias', '', '', '', 9);
INSERT INTO usuarios_lista_tablas VALUES (53, 'Banners', 'banners', '', '', '', 9);
INSERT INTO usuarios_lista_tablas VALUES (54, 'Secciones', 'secciones', '', '', '', 1);
INSERT INTO usuarios_lista_tablas VALUES (55, 'Perfiles', 'usuarios_perfiles', '', '', '', 1);
INSERT INTO usuarios_lista_tablas VALUES (56, 'Detalle Partido', '', '', 'especiales/ficha_partido.inc', '', 0);
INSERT INTO usuarios_lista_tablas VALUES (57, 'Clubes', 'futbol_clubes', '', '', '', 10);
INSERT INTO usuarios_lista_tablas VALUES (70, 'Jugadores', 'futbol_jugadores', '', '', '', 10);
INSERT INTO usuarios_lista_tablas VALUES (71, 'Trivias', 'trivias', '', '', '', 4);
INSERT INTO usuarios_lista_tablas VALUES (60, 'Partidos', 'futbol_partidos', '', '', '', 10);
INSERT INTO usuarios_lista_tablas VALUES (61, 'Torneos', 'futbol_torneos', '', '', '', 10);
INSERT INTO usuarios_lista_tablas VALUES (62, 'Planteles', 'futbol_planteles', '', '', '', 10);
INSERT INTO usuarios_lista_tablas VALUES (74, 'Fotos Columnistas', 'fotos_columnas', '', '', '', 11);
INSERT INTO usuarios_lista_tablas VALUES (64, 'Columnistas', 'columnistas', '', '', '', 11);
INSERT INTO usuarios_lista_tablas VALUES (65, 'Carreras', 'f1_carreras', '', '', '', 12);
INSERT INTO usuarios_lista_tablas VALUES (66, 'Clasificacion', 'f1_clasificacion', '', '', '', 12);
INSERT INTO usuarios_lista_tablas VALUES (67, 'Equipos', 'f1_equipos', '', '', '', 12);
INSERT INTO usuarios_lista_tablas VALUES (68, 'Fotos Pilotos', 'f1_imagenes_f1', '', '', '', 12);
INSERT INTO usuarios_lista_tablas VALUES (69, 'Pilotos', 'f1_pilotos', '', '', '', 12);
INSERT INTO usuarios_lista_tablas VALUES (72, 'Preguntas de la Trivia', '', '', 'especiales/trivia.inc', '', 0);
INSERT INTO usuarios_lista_tablas VALUES (73, 'Resumen Partidos', 'futbol_resumen', '', '', '', 10);
INSERT INTO usuarios_lista_tablas VALUES (75, 'Autores', 'autores', '', '', '', 4);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `usuarios_perfiles`
#

CREATE TABLE usuarios_perfiles (
  id int(11) NOT NULL auto_increment,
  perfil varchar(255) NOT NULL default '',
  ck_admin smallint(1) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `usuarios_perfiles`
#

INSERT INTO usuarios_perfiles VALUES (1, 'Administrador', 1);
INSERT INTO usuarios_perfiles VALUES (2, 'Periodista', 0);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `usuarios_permisos`
#

CREATE TABLE usuarios_permisos (
  id int(11) NOT NULL auto_increment,
  id_perfil int(10) NOT NULL default '0',
  id_tablas int(10) NOT NULL default '0',
  mostrar_listado mediumtext,
  deshabilitar_abm mediumtext,
  oculto_abm mediumtext,
  ck_activo tinyint(1) default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `usuarios_permisos`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `usuarios_rel_tab`
#

CREATE TABLE usuarios_rel_tab (
  id int(11) NOT NULL auto_increment,
  id_tablas int(10) NOT NULL default '0',
  id_solapas_tablas int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `usuarios_rel_tab`
#

INSERT INTO usuarios_rel_tab VALUES (1, 40, 43);
INSERT INTO usuarios_rel_tab VALUES (2, 40, 44);
INSERT INTO usuarios_rel_tab VALUES (3, 41, 43);
INSERT INTO usuarios_rel_tab VALUES (4, 41, 44);
INSERT INTO usuarios_rel_tab VALUES (5, 36, 43);
INSERT INTO usuarios_rel_tab VALUES (6, 36, 44);
INSERT INTO usuarios_rel_tab VALUES (7, 33, 44);
INSERT INTO usuarios_rel_tab VALUES (9, 47, 48);
INSERT INTO usuarios_rel_tab VALUES (10, 40, 50);
INSERT INTO usuarios_rel_tab VALUES (11, 53, 44);
INSERT INTO usuarios_rel_tab VALUES (12, 47, 44);
INSERT INTO usuarios_rel_tab VALUES (13, 60, 56);
INSERT INTO usuarios_rel_tab VALUES (14, 71, 72);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `usuarios_sectores`
#

CREATE TABLE usuarios_sectores (
  id int(11) NOT NULL auto_increment,
  sector varchar(255) NOT NULL default '',
  descripcion varchar(255) default NULL,
  orden int(3) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `usuarios_sectores`
#

INSERT INTO usuarios_sectores VALUES (1, 'Administracion', NULL, 1);
INSERT INTO usuarios_sectores VALUES (2, 'Noticias', NULL, 2);
INSERT INTO usuarios_sectores VALUES (3, 'Calendario', 'NULL', 4);
INSERT INTO usuarios_sectores VALUES (4, 'General', 'NULL', 7);
INSERT INTO usuarios_sectores VALUES (9, 'Multimedia', 'NULL', 9);
INSERT INTO usuarios_sectores VALUES (8, 'Suscriptos', 'NULL', 8);
INSERT INTO usuarios_sectores VALUES (10, 'Especiales Futbol', '', 20);
INSERT INTO usuarios_sectores VALUES (11, 'Columnas', '', 3);

